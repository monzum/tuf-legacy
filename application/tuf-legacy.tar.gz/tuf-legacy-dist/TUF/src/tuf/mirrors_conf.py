mirrors = {'mirror1': {'url_prefix' : 'http://localhost:8000',
                         'metadata_path' : 'metadata',
                         'targets_path' : 'targets',
                         'confined_target_paths' : ['']},
             'mirror2': {'url_prefix' : 'http://localhost:8001',
                         'metadata_path' : 'metadata',
                         'targets_path' : 'targets',
                         'confined_target_paths' : ['']},
             'mirror3': {'url_prefix' : 'http://localhost:8002',
                         'metadata_path' : 'metadata',
                         'targets_path' : 'targets',
                         'confined_target_paths' : ['']}
	    }

