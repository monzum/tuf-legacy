"""
Simple test to check libc interpose works
usage:
 	1. Go to src/libc and get libcnetworkinterpose.so and load_shim_proxy.sh files in same dir
	2. do: python libcnetworkinterpose_test.py
		If everything is ok, socket object description is printed out
	3. In the same shell:
		do : . load_shim_proxy.sh
	 	do : python libcnetworkinterpose_test.py
	4. test should crash
"""	
#socket doimport urllib2
import socket

s = socket.socket(2, socket.SOCK_STREAM)
print s

