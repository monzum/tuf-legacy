#basic localhost server running in port 8101
#to simulate the server of our platform
import SimpleHTTPServer
import SocketServer

PORT = 8101

Handler = SimpleHTTPServer.SimpleHTTPRequestHandler

httpd = SocketServer.TCPServer(("", PORT), Handler)

print "Server serving at port", PORT
httpd.serve_forever()
