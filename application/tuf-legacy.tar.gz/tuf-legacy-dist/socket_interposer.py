#Jerry B. backer bataille16@gmail.com
#11/06/2012

#The purpose of this function is to interpose 
#on the trapped network calls (see src/libc for 
# network call trapping mechanism) and send the 
#calls to the TUFTranslator (see tuf_api_translator.py) to
#be processe This script should be run in a separate shell 
#before starting the legacy software updater processed

#usage: (on a separate shell) python socket_interposer.py 

import libnit_listener
from  tuf_api_translator import TUFTranslator

def main():
	#for now (testing purposes), we hardcode the server url
	# it can just as easily be passed as a command-line argument
	test = TUFTranslator("http://localhost:8101")
	
	new_listener = libnit_listener.LibnitListener(test, debug_mode = True) 
   	new_listener.serve_forever()


if __name__ == "__main__":
	main()	
